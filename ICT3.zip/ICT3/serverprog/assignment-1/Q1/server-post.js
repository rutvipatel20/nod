const http = require('http');
const fs = require('fs');
const port = process.env.PORT || 8000;
const server = http.createServer((req, res) => {
    if (req.url == "/") {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write("hello from the server");
        return res.end();
    }
    else if (req.url == "/process" && req.method == 'POST') {
        let body = '';
        req.on('data', (chunk) => {
            body += chunk;
        });

        req.on('end', () => {
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Hello, this is a POST request with body: ' + body);
            console.log(body);


        });
    }
    else if (req.url == "/index.html" && req.method == 'GET') {
        var filename = "./index.html";
        fs.readFile(filename, function (err, data) {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                return res.end("404");
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            console.log(data);
            res.write(data);
            return res.end();
        });
    }
});
server.listen(port, () => {
    console.log(`server is listening on ${port}`);
});