module.exports.f1 = function ();
{
    console.log("f1")
}