# initialbackend

This is a [Node.js](https://nodejs.org/) project 
​
## Project setup

1 > use this url as mongo db database url​ 👉 "mongodb+srv://dummy:dymmydb%40mongo@dummydb.cw083ce.mongodb.net/test"

2 > download the MongoDB Compass for desktop and connect with above MongoDB url 👆

3 > install node modules "npm install" 

4 > use "npm run start" 
    
    [nodemon] watching path(s): *.*
    [nodemon] watching extensions: js,mjs,json
    [nodemon] starting `node app.js`
    Server engine 5555 started...🚀🚀
    🟢 Database Initiated......😎

!! Database is connected now !!

5 > use "http://localhost:5555/api" as base url in postman 