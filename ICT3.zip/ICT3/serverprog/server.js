const http = require('http');
const events = require('events');
const eventEmitter = new events.EventEmitter();
eventEmitter.on('connection', () => {
    console.log('connected');
});
eventEmitter.on('data_received', () => {
    console.log('data_received');
});
const server = http.createServer((req, res) => {
    if (req.url == '/start') {
        eventEmitter.emit('connection');
        res.end('You Have Successfully connected to the server');
    }
    else if (req.url == '/data') {
        eventEmitter.emit('data_received');
        res.end('You Have Received data');
    }
    else { 
        res.end('1. /start to start the connection.\n2. /data to tell data is received.');
    }
});
server.listen(8000);