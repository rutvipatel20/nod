const http = require('http');

const server = http.createServer(function (req, res) {
    console.log("req received:" + req.url);
    if (req.url == "/") {
        res.write("Hello");
        res.write("Hello1");
        res.end();
    }

    else if (req.url == "/list") {
        res.write("<html><body><h1>list</h1></body></html>");
        res.end();
    }

    else {
        res.write("other page");
        res.end();
    }

});

server.listen(8080);
console.log("listening on port no 8080");
