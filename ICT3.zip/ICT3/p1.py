print("Hello")
x = [10, 12, 20]
print(x)
